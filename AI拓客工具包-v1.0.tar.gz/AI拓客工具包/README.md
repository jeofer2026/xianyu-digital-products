# 🤖 AI拓客工具包 v1.0

## 功能
- 📧 自动采集目标客户邮箱
- 📤 自动发送个性化开发信（模仿真人节奏）
- 📥 自动收信 + 意向分析
- 📊 自动生成日报/周报

## 快速开始

### 1. 安装依赖
```bash
pip install openpyxl
```

### 2. 配置
编辑 `scripts/config.json`，填写你的邮箱和授权码

### 3. 导入客户
```bash
# 方式1：手动添加
python3 scripts/ai_sales_kit.py add "xx@163.com" "XX公司"

# 方式2：批量导入CSV
python3 scripts/ai_sales_kit.py import templates/客户导入模板.csv
```

### 4. 发送开发信
```bash
python3 scripts/ai_sales_kit.py send 10
```

### 5. 检查回复
```bash
python3 scripts/ai_sales_kit.py check
```

### 6. 查看报表
```bash
python3 scripts/ai_sales_kit.py report    # 日报
python3 scripts/ai_sales_kit.py weekly    # 周报
```

## 注意事项
- 每日发送上限50封，防止被封
- 每封间隔30-120秒随机，模仿真人
- 支持126/163/QQ邮箱
- 需要开启SMTP/IMAP服务

## 技术支持
如有问题，联系：庞经理 15226664060
