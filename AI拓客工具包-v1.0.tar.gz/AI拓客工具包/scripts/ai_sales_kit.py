#!/usr/bin/env python3
"""
AI拓客工具包 v1.0
==================
功能：自动采集目标客户邮箱 + 自动发送开发信 + 自动收信分析
作者：AI销售助理
"""

import json
import time
import random
import smtplib
import imaplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import decode_header
from datetime import datetime, timedelta
import os
import sys
import csv
import re

# ============================================================
# 配置区（用户填写）
# ============================================================
CONFIG = {
    # 发件人配置
    "sender_email": "your_email@126.com",      # 修改为你的邮箱
    "sender_password": "your_auth_code",        # 修改为你的授权码
    "sender_name": "庞经理",                    # 发件人名称
    "smtp_server": "smtp.126.com",
    "smtp_port": 465,
    "imap_server": "imap.126.com",
    "imap_port": 993,

    # 拓客配置
    "target_industry": "消防工程",              # 目标行业
    "target_region": "河北",                    # 目标地区
    "daily_send_limit": 50,                     # 每日发送上限
    "send_interval_min": 30,                    # 最小发送间隔（秒）
    "send_interval_max": 120,                   # 最大发送间隔（秒）

    # 文件路径
    "leads_file": "leads.json",                 # 客户数据
    "send_log_file": "send_log.json",           # 发送日志
    "replies_file": "replies_log.json",         # 回复记录
    "stats_file": "daily_stats.json",           # 统计数据
}


# ============================================================
# 模块1：客户邮箱采集
# ============================================================
class EmailCollector:
    """从公开数据源采集目标客户邮箱"""

    def __init__(self, config):
        self.config = config
        self.leads = self._load_leads()

    def _load_leads(self):
        """加载已有客户数据"""
        if os.path.exists(self.config["leads_file"]):
            with open(self.config["leads_file"], "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def _save_leads(self):
        """保存客户数据"""
        with open(self.config["leads_file"], "w", encoding="utf-8") as f:
            json.dump(self.leads, f, ensure_ascii=False, indent=2)

    def add_lead(self, company, email_addr, lead_type="企业", source="手动录入", phone="", address=""):
        """手动添加客户"""
        # 去重
        for lead in self.leads:
            if lead["email"] == email_addr:
                print(f"⚠️ 邮箱已存在：{email_addr}")
                return False

        lead = {
            "id": len(self.leads) + 1,
            "company": company,
            "email": email_addr,
            "type": lead_type,
            "source": source,
            "phone": phone,
            "address": address,
            "status": "待开发",
            "created_at": datetime.now().isoformat(),
            "last_followup": None,
        }
        self.leads.append(lead)
        self._save_leads()
        print(f"✅ 已添加：{company} - {email_addr}")
        return True

    def batch_add_from_csv(self, csv_file):
        """从CSV批量导入客户"""
        count = 0
        with open(csv_file, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                email_addr = row.get("邮箱", row.get("email", "")).strip()
                company = row.get("公司", row.get("company", "未知")).strip()
                if email_addr and "@" in email_addr:
                    if self.add_lead(company, email_addr):
                        count += 1
        print(f"✅ 批量导入完成：{count} 条")
        return count

    def get_pending_leads(self, limit=50):
        """获取待开发的客户"""
        pending = [l for l in self.leads if l["status"] == "待开发"]
        return pending[:limit]

    def get_stats(self):
        """获取统计信息"""
        total = len(self.leads)
        pending = sum(1 for l in self.leads if l["status"] == "待开发")
        sent = sum(1 for l in self.leads if l["status"] == "已发送")
        replied = sum(1 for l in self.leads if l["status"] == "已回复")
        invalid = sum(1 for l in self.leads if l["status"] == "无效")
        return {
            "total": total,
            "pending": pending,
            "sent": sent,
            "replied": replied,
            "invalid": invalid,
        }

    def print_stats(self):
        """打印统计信息"""
        stats = self.get_stats()
        print("\n" + "=" * 50)
        print("📊 客户数据统计")
        print("=" * 50)
        print(f"  总客户数：{stats['total']}")
        print(f"  待开发：  {stats['pending']}")
        print(f"  已发送：  {stats['sent']}")
        print(f"  已回复：  {stats['replied']}")
        print(f"  无效：    {stats['invalid']}")
        if stats['sent'] > 0:
            rate = stats['replied'] / stats['sent'] * 100
            print(f"  回复率：  {rate:.1f}%")
        print("=" * 50 + "\n")


# ============================================================
# 模块2：开发信发送
# ============================================================
class EmailSender:
    """自动发送开发信"""

    def __init__(self, config):
        self.config = config
        self.send_log = self._load_send_log()

    def _load_send_log(self):
        """加载发送日志"""
        if os.path.exists(self.config["send_log_file"]):
            with open(self.config["send_log_file"], "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def _save_send_log(self):
        """保存发送日志"""
        with open(self.config["send_log_file"], "w", encoding="utf-8") as f:
            json.dump(self.send_log, f, ensure_ascii=False, indent=2)

    def _create_email(self, to_email, to_company, template_type="通用"):
        """创建邮件"""
        templates = {
            "通用": {
                "subject": "【工厂直供】防火涂料 资质齐全 可配合投标+免费寄样",
                "body": """您好！

我是{company}的{person}，专注于防火材料生产销售。

我们主营：
• 室内/室外钢结构防火涂料（薄型/超薄型/厚型）
• 电缆防火涂料、隧道防火涂料
• 防火封堵材料（堵料、阻火包、模块、板材）

✅ 资质齐全：ISO9001认证 + 消防产品认证
✅ 工厂直供：价格有优势，可配合投标
✅ 免费寄样：支持先试后买

如有需要，欢迎随时联系！

---
{person}
{company}
电话：{phone}
地址：{address}"""
            },
            "价格吸引": {
                "subject": "防火涂料工厂底价 850元/吨起 国标认证",
                "body": """您好！

{company}专注防火材料生产，现推出优惠活动：

🔥 厚型钢结构防火涂料：850元/吨
🔥 薄型/超薄型防火涂料：1350元/吨
🔥 电缆防火涂料、隧道防火涂料：优惠价

✅ 国标认证（GB14907-2018）
✅ 免费寄样 + 技术指导
✅ 量大从优，可配合投标

欢迎询价！

---
{person}
{company}
电话：{phone}
地址：{address}"""
            },
            "工程专用": {
                "subject": "工程防火材料一站式供应 全套资质可报审",
                "body": """您好！

{company}是专业防火材料生产厂家，为工程项目提供一站式供应：

📋 产品清单：
• 钢结构防火涂料（室内/室外）
• 电缆防火涂料
• 隧道防火涂料
• 防火封堵系统（堵料、包、模块、板材）

📋 资质文件：
• ISO9001:2015 质量管理体系认证
• 消防产品认证证书
• 全套检测报告

可配合投标报审，欢迎工程合作！

---
{person}
{company}
电话：{phone}
地址：{address}"""
            },
        }

        template = templates.get(template_type, templates["通用"])
        subject = template["subject"]
        body = template["body"].format(
            company=self.config.get("sender_company", "信泰防火材料"),
            person=self.config.get("sender_name", "庞经理"),
            phone=self.config.get("sender_phone", "15226664060"),
            address=self.config.get("sender_address", "河北省沧州市任丘市"),
        )

        msg = MIMEMultipart()
        msg["From"] = f"{self.config['sender_name']} <{self.config['sender_email']}>"
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain", "utf-8"))
        return msg

    def send_email(self, to_email, to_company, template_type="通用"):
        """发送单封邮件"""
        try:
            msg = self._create_email(to_email, to_company, template_type)

            # 每封邮件独立连接
            server = smtplib.SMTP_SSL(self.config["smtp_server"], self.config["smtp_port"])
            server.login(self.config["sender_email"], self.config["sender_password"])
            server.send_message(msg)
            server.quit()

            # 记录日志
            log_entry = {
                "to_email": to_email,
                "to_company": to_company,
                "subject": msg["Subject"],
                "sent_at": datetime.now().isoformat(),
                "template": template_type,
                "status": "已发送",
            }
            self.send_log.append(log_entry)
            self._save_send_log()
            print(f"✅ 已发送：{to_company} - {to_email}")
            return True

        except smtplib.SMTPRecipientsRefused:
            print(f"❌ 收件人拒绝：{to_email}")
            return False
        except smtplib.SMTPServerDisconnected:
            print(f"⚠️ 服务器断开，等待重试...")
            return False
        except Exception as e:
            print(f"❌ 发送失败：{to_email} - {str(e)}")
            return False

    def send_batch(self, leads, template_type="通用"):
        """批量发送（自动间隔，模仿真人）"""
        results = {"success": 0, "failed": 0, "skipped": 0}

        for i, lead in enumerate(leads):
            # 检查今日发送量
            today = datetime.now().strftime("%Y-%m-%d")
            today_sent = sum(1 for log in self.send_log if log["sent_at"].startswith(today))
            if today_sent >= self.config["daily_send_limit"]:
                print(f"⚠️ 今日已发送 {today_sent} 封，达到上限，停止发送")
                results["skipped"] += len(leads) - i
                break

            # 发送
            success = self.send_email(lead["email"], lead["company"], template_type)
            if success:
                results["success"] += 1
            else:
                results["failed"] += 1

            # 间隔（最后一封不需要等）
            if i < len(leads) - 1:
                wait = random.randint(self.config["send_interval_min"], self.config["send_interval_max"])
                print(f"⏳ 等待 {wait} 秒...")
                time.sleep(wait)

        print(f"\n📊 发送完成：成功 {results['success']} / 失败 {results['failed']} / 跳过 {results['skipped']}")
        return results


# ============================================================
# 模块3：收件分析
# ============================================================
class EmailAnalyzer:
    """自动收信并分析客户意向"""

    def __init__(self, config):
        self.config = config
        self.replies = self._load_replies()

    def _load_replies(self):
        """加载回复记录"""
        if os.path.exists(self.config["replies_file"]):
            with open(self.config["replies_file"], "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def _save_replies(self):
        """保存回复记录"""
        with open(self.config["replies_file"], "w", encoding="utf-8") as f:
            json.dump(self.replies, f, ensure_ascii=False, indent=2)

    def check_replies(self):
        """检查收件箱，获取新回复"""
        new_replies = []

        try:
            # 连接IMAP
            mail = imaplib.IMAP4_SSL(self.config["imap_server"], self.config["imap_port"])
            mail.login(self.config["sender_email"], self.config["sender_password"])

            # 伪装Thunderbird（绕过126安全检查）
            tag = mail._new_tag()
            mail.send(tag + b' ID ("name" "Thunderbird" "version" "115.0")\r\n')
            while True:
                line = mail.readline()
                if line.startswith(tag) or not line:
                    break
            time.sleep(0.5)

            # 选择收件箱
            mail.select("INBOX")

            # 搜索未读邮件
            status, messages = mail.search(None, "UNSEEN")
            if status != "OK":
                print("⚠️ 搜索邮件失败")
                mail.logout()
                return []

            msg_ids = messages[0].split()
            print(f"📬 发现 {len(msg_ids)} 封新邮件")

            for msg_id in msg_ids:
                status, msg_data = mail.fetch(msg_id, "(RFC822)")
                if status != "OK":
                    continue

                raw_email = msg_data[0][1]
                msg = email.message_from_bytes(raw_email)

                # 解析发件人
                from_header = decode_header(msg["From"])
                from_str = ""
                for part, charset in from_header:
                    if isinstance(part, bytes):
                        from_str += part.decode(charset or "utf-8", errors="ignore")
                    else:
                        from_str += part

                # 提取邮箱
                email_match = re.search(r'<(.+?)>', from_str)
                from_email = email_match.group(1) if email_match else from_str

                # 解析主题
                subject_header = decode_header(msg["Subject"])
                subject = ""
                for part, charset in subject_header:
                    if isinstance(part, bytes):
                        subject += part.decode(charset or "utf-8", errors="ignore")
                    else:
                        subject += part

                # 解析正文
                body = ""
                if msg.is_multipart():
                    for part in msg.walk():
                        if part.get_content_type() == "text/plain":
                            charset = part.get_content_charset() or "utf-8"
                            body = part.get_payload(decode=True).decode(charset, errors="ignore")
                            break
                else:
                    charset = msg.get_content_charset() or "utf-8"
                    body = msg.get_payload(decode=True).decode(charset, errors="ignore")

                # 判断回复类型
                is_auto_reply = self._is_auto_reply(subject, body)
                is_bounce = self._is_bounce(subject, body)
                intent = self._analyze_intent(subject, body)

                reply_record = {
                    "from_email": from_email,
                    "from_name": from_str,
                    "subject": subject,
                    "body_preview": body[:200],
                    "received_at": datetime.now().isoformat(),
                    "is_auto_reply": is_auto_reply,
                    "is_bounce": is_bounce,
                    "intent": intent,
                    "is_new": True,
                }

                new_replies.append(reply_record)
                self.replies.append(reply_record)

                # 打印
                intent_emoji = {"高意向": "🔥", "中意向": "⭐", "低意向": "📌", "无意向": "⚪"}.get(intent, "❓")
                auto_tag = " [自动回复]" if is_auto_reply else ""
                bounce_tag = " [退信]" if is_bounce else ""
                print(f"  {intent_emoji} {from_email} - {subject[:40]}{auto_tag}{bounce_tag}")

            mail.logout()

        except Exception as e:
            print(f"❌ 收信失败：{str(e)}")

        self._save_replies()
        return new_replies

    def _is_auto_reply(self, subject, body):
        """判断是否为自动回复"""
        auto_keywords = ["自动回复", "auto reply", "out of office", "休假", "不在办公室"]
        text = (subject + body).lower()
        return any(kw in text for kw in auto_keywords)

    def _is_bounce(self, subject, body):
        """判断是否为退信"""
        bounce_keywords = ["退信", "bounce", "undeliverable", "delivery failed", "邮件投递失败"]
        text = (subject + body).lower()
        return any(kw in text for kw in bounce_keywords)

    def _analyze_intent(self, subject, body):
        """分析客户意向"""
        text = (subject + body).lower()

        # 高意向关键词
        high_keywords = ["报价", "价格", "多少钱", "样品", "寄样", "合作", "采购", "招标", "投标", "详细", "资料"]
        if any(kw in text for kw in high_keywords):
            return "高意向"

        # 中意向关键词
        mid_keywords = ["了解", "咨询", "看看", "参考", "考虑", "需要", "有兴趣"]
        if any(kw in text for kw in mid_keywords):
            return "中意向"

        # 低意向关键词
        low_keywords = ["收到", "谢谢", "已阅", "暂时", "不需要"]
        if any(kw in text for kw in low_keywords):
            return "低意向"

        return "无意向"

    def get_intent_summary(self):
        """获取意向统计"""
        summary = {"高意向": 0, "中意向": 0, "低意向": 0, "无意向": 0, "自动回复": 0, "退信": 0}
        for reply in self.replies:
            if reply.get("is_auto_reply"):
                summary["自动回复"] += 1
            elif reply.get("is_bounce"):
                summary["退信"] += 1
            else:
                intent = reply.get("intent", "无意向")
                summary[intent] = summary.get(intent, 0) + 1
        return summary

    def print_summary(self):
        """打印意向分析"""
        summary = self.get_intent_summary()
        print("\n" + "=" * 50)
        print("📊 客户意向分析")
        print("=" * 50)
        print(f"  🔥 高意向：  {summary['高意向']}")
        print(f"  ⭐ 中意向：  {summary['中意向']}")
        print(f"  📌 低意向：  {summary['低意向']}")
        print(f"  ⚪ 无意向：  {summary['无意向']}")
        print(f"  🤖 自动回复：{summary['自动回复']}")
        print(f"  ❌ 退信：    {summary['退信']}")
        print("=" * 50 + "\n")


# ============================================================
# 模块4：数据报表
# ============================================================
class ReportGenerator:
    """生成每日/每周数据报表"""

    def __init__(self, collector, sender, analyzer):
        self.collector = collector
        self.sender = sender
        self.analyzer = analyzer

    def generate_daily_report(self):
        """生成每日报表"""
        today = datetime.now().strftime("%Y-%m-%d")

        # 今日发送量
        today_sent = sum(1 for log in self.sender.send_log if log["sent_at"].startswith(today))

        # 今日回复
        today_replies = sum(1 for r in self.analyzer.replies if r["received_at"].startswith(today))

        # 客户统计
        stats = self.collector.get_stats()

        # 意向分析
        intent = self.analyzer.get_intent_summary()

        report = f"""
{'=' * 50}
📊 AI拓客日报 - {today}
{'=' * 50}

📧 今日发送：{today_sent} 封
📬 今日回复：{today_replies} 封

📈 客户统计：
  总客户：{stats['total']} | 待开发：{stats['pending']}
  已发送：{stats['sent']} | 已回复：{stats['replied']}

🔥 意向分析：
  高意向：{intent['高意向']} | 中意向：{intent['中意向']}
  低意向：{intent['低意向']} | 自动回复：{intent['自动回复']}

{'=' * 50}
"""
        print(report)
        return report

    def generate_weekly_report(self):
        """生成每周报表"""
        # 计算过去7天数据
        week_ago = (datetime.now() - timedelta(days=7)).isoformat()

        week_sent = sum(1 for log in self.sender.send_log if log["sent_at"] > week_ago)
        week_replies = sum(1 for r in self.analyzer.replies if r["received_at"] > week_ago)
        stats = self.collector.get_stats()
        intent = self.analyzer.get_intent_summary()

        report = f"""
{'=' * 50}
📊 AI拓客周报
{'=' * 50}

📧 本周发送：{week_sent} 封
📬 本周回复：{week_replies} 封
  回复率：{week_replies / week_sent * 100:.1f}%（如发送量>0）

📈 客户统计：
  总客户：{stats['total']} | 待开发：{stats['pending']}
  已发送：{stats['sent']} | 已回复：{stats['replied']}

🔥 意向分析：
  高意向：{intent['高意向']} | 中意向：{intent['中意向']}
  低意向：{intent['低意向']} | 自动回复：{intent['自动回复']}

💡 建议：
  - 高意向客户建议立即跟进
  - 中意向客户3天内跟进
  - 低意向客户每周维护

{'=' * 50}
"""
        print(report)
        return report


# ============================================================
# 主程序
# ============================================================
def main():
    """主入口"""
    print("🤖 AI拓客工具包 v1.0")
    print("=" * 50)

    # 初始化
    collector = EmailCollector(CONFIG)
    sender = EmailSender(CONFIG)
    analyzer = EmailAnalyzer(CONFIG)
    reporter = ReportGenerator(collector, sender, analyzer)

    # 命令行参数
    if len(sys.argv) < 2:
        print("""
用法：
  python3 ai_sales_kit.py stats          # 查看统计
  python3 ai_sales_kit.py add <邮箱> <公司>  # 添加客户
  python3 ai_sales_kit.py import <csv文件>   # 批量导入
  python3 ai_sales_kit.py send <数量>        # 发送开发信
  python3 ai_sales_kit.py check             # 检查回复
  python3 ai_sales_kit.py report            # 生成日报
  python3 ai_sales_kit.py weekly            # 生成周报
        """)
        return

    command = sys.argv[1]

    if command == "stats":
        collector.print_stats()
        analyzer.print_summary()

    elif command == "add" and len(sys.argv) >= 4:
        email_addr = sys.argv[2]
        company = sys.argv[3]
        collector.add_lead(company, email_addr)

    elif command == "import" and len(sys.argv) >= 3:
        csv_file = sys.argv[2]
        collector.batch_add_from_csv(csv_file)

    elif command == "send" and len(sys.argv) >= 3:
        limit = int(sys.argv[2])
        leads = collector.get_pending_leads(limit)
        if leads:
            print(f"📧 准备发送 {len(leads)} 封开发信...")
            results = sender.send_batch(leads)
            # 更新客户状态
            for lead in leads[:results["success"]]:
                lead["status"] = "已发送"
            collector._save_leads()
        else:
            print("⚠️ 没有待开发的客户")

    elif command == "check":
        print("📬 检查收件箱...")
        new_replies = analyzer.check_replies()
        if new_replies:
            print(f"\n✅ 发现 {len(new_replies)} 封新回复")
            analyzer.print_summary()
        else:
            print("📭 没有新回复")

    elif command == "report":
        reporter.generate_daily_report()

    elif command == "weekly":
        reporter.generate_weekly_report()

    else:
        print("⚠️ 未知命令，查看用法：python3 ai_sales_kit.py")


if __name__ == "__main__":
    main()
